#pragma once

class ${NAME} {
    public:
       ${NAME}() = default;  
    private:           
};


