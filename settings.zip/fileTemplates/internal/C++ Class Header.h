#pragma once
${NAMESPACES_OPEN}
class ${NAME} {
    public:
       ${NAME}() = default;  
    private:           
};
${NAMESPACES_CLOSE}

